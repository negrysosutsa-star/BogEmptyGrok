package ru.bogempty;

import net.fabricmc.api.ClientModInitializer;
import ru.bogempty.module.ModuleManager;
import ru.bogempty.event.EventBus;

public class BogEmptyClient implements ClientModInitializer {
    public static BogEmptyClient INSTANCE;
    public static final String NAME = "BogEmpty";
    public static final String VERSION = "1.0.0";

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        ModuleManager.init();
        EventBus.init();
        System.out.println("[BogEmpty] loaded " + VERSION);
    }
}
