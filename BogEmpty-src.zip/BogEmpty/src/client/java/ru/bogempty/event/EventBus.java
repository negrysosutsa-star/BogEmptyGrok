package ru.bogempty.event;

import ru.bogempty.module.Module;
import ru.bogempty.module.ModuleManager;

public class EventBus {
    public static void init() {
        // hooks via mixins
    }

    public static void onTick() {
        for (Module m : ModuleManager.modules) {
            if (m.enabled) m.onTick();
        }
    }
}
