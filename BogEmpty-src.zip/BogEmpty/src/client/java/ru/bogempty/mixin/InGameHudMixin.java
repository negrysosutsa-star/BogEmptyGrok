package ru.bogempty.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.bogempty.module.Module;
import ru.bogempty.module.ModuleManager;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("RETURN"))
    private void onRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        float td = tickCounter.getTickDelta(false);
        for (Module m : ModuleManager.modules) {
            if (m.enabled) m.onRender2D(context, td);
        }
        // watermark always
        context.drawTextWithShadow(
                net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                "BOGEMPTY",
                4, 4,
                0xFFAA00FF
        );
    }
}
