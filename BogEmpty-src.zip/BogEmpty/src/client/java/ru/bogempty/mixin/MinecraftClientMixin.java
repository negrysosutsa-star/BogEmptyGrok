package ru.bogempty.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.bogempty.module.Module;
import ru.bogempty.module.ModuleManager;
import ru.bogempty.module.modules.misc.ClickGuiModule;
import org.lwjgl.glfw.GLFW;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Inject(method = "handleInputEvents", at = @At("HEAD"))
    private void onKey(CallbackInfo ci) {
        // keybind handling simplified — real needs KeyBinding or GLFW poll
        // for now ClickGUI opens via module enable
    }
}
