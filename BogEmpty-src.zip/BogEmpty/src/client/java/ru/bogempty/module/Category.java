package ru.bogempty.module;

public enum Category {
    COMBAT("Combat"),
    VISUALS("Visuals"),
    PVE("PvE"),
    MISC("Misc"),
    CONFIG("Config");

    public final String name;

    Category(String name) {
        this.name = name;
    }
}
