package ru.bogempty.module;

import ru.bogempty.module.modules.combat.AimAssist;
import ru.bogempty.module.modules.combat.Sprint;
import ru.bogempty.module.modules.combat.TriggerBot;
import ru.bogempty.module.modules.misc.ClickGuiModule;
import ru.bogempty.module.modules.pve.AuctionHelper;
import ru.bogempty.module.modules.pve.FunTimeHelper;
import ru.bogempty.module.modules.pve.InventoryCollector;
import ru.bogempty.module.modules.visuals.AspectRatio;
import ru.bogempty.module.modules.visuals.ESP;
import ru.bogempty.module.modules.visuals.GuiMove;
import ru.bogempty.module.modules.visuals.NoRender;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();

    public static void init() {
        // Combat
        modules.add(new TriggerBot());
        modules.add(new AimAssist());
        modules.add(new Sprint());

        // Visuals
        modules.add(new ESP());
        modules.add(new AspectRatio());
        modules.add(new NoRender());
        modules.add(new GuiMove());

        // PvE
        modules.add(new InventoryCollector());
        modules.add(new AuctionHelper());
        modules.add(new FunTimeHelper());

        // Misc
        modules.add(new ClickGuiModule());
    }

    public static Module get(Class<? extends Module> clazz) {
        for (Module m : modules) {
            if (m.getClass() == clazz) return m;
        }
        return null;
    }

    public static List<Module> getByCategory(Category cat) {
        List<Module> list = new ArrayList<>();
        for (Module m : modules) {
            if (m.category == cat) list.add(m);
        }
        return list;
    }
}
