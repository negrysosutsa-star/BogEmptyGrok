package ru.bogempty.module.modules.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;
import ru.bogempty.module.setting.ModeSetting;
import ru.bogempty.module.setting.NumberSetting;

public class AimAssist extends Module {
    public final NumberSetting range = new NumberSetting("Distance", 4.5, 1.0, 8.0, 0.1);
    public final ModeSetting mode = new ModeSetting("Mode", "Helper", "Helper", "Smooth", "Default");
    public final NumberSetting speed = new NumberSetting("Speed", 0.35, 0.05, 1.0, 0.01);
    public final NumberSetting strength = new NumberSetting("Strength", 0.6, 0.1, 1.0, 0.05);
    public final NumberSetting shake = new NumberSetting("Shake", 0.0, 0.0, 2.0, 0.1);
    public final NumberSetting fov = new NumberSetting("FOV", 90, 10, 180, 5);
    public final ModeSetting targets = new ModeSetting("Targets", "Players", "Players", "Mobs", "All");
    public final NumberSetting sensComp = new NumberSetting("SensComp", 1.0, 0.5, 2.0, 0.05);

    public AimAssist() {
        super("AimAssist", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null) return;

        Entity target = findTarget();
        if (target == null) return;

        Vec3d eyes = mc.player.getEyePos();
        Vec3d aimPoint = target.getPos().add(0, target.getHeight() * 0.85, 0); // roughly head

        double dx = aimPoint.x - eyes.x;
        double dy = aimPoint.y - eyes.y;
        double dz = aimPoint.z - eyes.z;

        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist > range.get()) return;

        float targetYaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float targetPitch = (float) -(MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * (180.0 / Math.PI));

        float currentYaw = mc.player.getYaw();
        float currentPitch = mc.player.getPitch();

        float yawDiff = MathHelper.wrapDegrees(targetYaw - currentYaw);
        float pitchDiff = targetPitch - currentPitch;

        // FOV check
        if (Math.abs(yawDiff) > fov.get() / 2f || Math.abs(pitchDiff) > fov.get() / 2f) return;

        float factor = speed.getFloat() * strength.getFloat() * sensComp.getFloat();
        if (mode.is("Helper")) factor *= 0.45f;
        if (mode.is("Smooth")) factor *= 0.7f;

        float newYaw = currentYaw + yawDiff * factor;
        float newPitch = currentPitch + pitchDiff * factor;

        if (shake.get() > 0) {
            newYaw += (Math.random() - 0.5) * shake.get();
            newPitch += (Math.random() - 0.5) * shake.get() * 0.5;
        }

        mc.player.setYaw(newYaw);
        mc.player.setPitch(MathHelper.clamp(newPitch, -90f, 90f));
    }

    private Entity findTarget() {
        Entity best = null;
        double bestDist = range.get();

        for (Entity e : mc.world.getEntities()) {
            if (!isValid(e)) continue;
            double d = mc.player.distanceTo(e);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    private boolean isValid(Entity e) {
        if (!(e instanceof LivingEntity living) || !living.isAlive()) return false;
        if (e == mc.player) return false;
        if (targets.is("Players")) return e instanceof PlayerEntity;
        if (targets.is("Mobs")) return e instanceof HostileEntity;
        return true;
    }
}
