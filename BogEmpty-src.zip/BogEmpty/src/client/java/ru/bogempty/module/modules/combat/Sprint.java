package ru.bogempty.module.modules.combat;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.forwardSpeed > 0 && !mc.player.isSneaking() && !mc.player.isUsingItem()) {
            mc.player.setSprinting(true);
        }
    }
}
