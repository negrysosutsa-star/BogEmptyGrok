package ru.bogempty.module.modules.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;
import ru.bogempty.module.setting.ModeSetting;
import ru.bogempty.module.setting.NumberSetting;

public class TriggerBot extends Module {
    public final ModeSetting mode = new ModeSetting("Mode", "Смарт криты", "Смарт криты", "Умные криты", "Только криты");
    public final NumberSetting range = new NumberSetting("Distance", 3.0, 1.0, 6.0, 0.1);
    public final ModeSetting targets = new ModeSetting("Targets", "Players", "Players", "Mobs", "All");
    public final NumberSetting delay = new NumberSetting("Delay", 50, 0, 200, 5);

    private long lastAttack = 0;

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;

        if (!(mc.crosshairTarget instanceof EntityHitResult ehr)) return;
        Entity target = ehr.getEntity();
        if (!isValid(target)) return;

        double dist = mc.player.distanceTo(target);
        if (dist > range.get()) return;

        if (mc.player.getAttackCooldownProgress(0.5f) < 0.92f) return;

        long now = System.currentTimeMillis();
        if (now - lastAttack < delay.getInt()) return;

        boolean canCrit = !mc.player.isOnGround() && mc.player.fallDistance > 0.0f && !mc.player.isClimbing() && !mc.player.isTouchingWater();

        if (mode.is("Только криты") && !canCrit) return;
        if (mode.is("Умные криты") && !canCrit && mc.player.isOnGround()) return;
        // Смарт криты — бьёт всегда, но предпочитает криты (уже фильтр выше)

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        lastAttack = now;
    }

    private boolean isValid(Entity e) {
        if (!(e instanceof LivingEntity living) || !living.isAlive()) return false;
        if (e == mc.player) return false;

        if (targets.is("Players")) return e instanceof PlayerEntity;
        if (targets.is("Mobs")) return e instanceof HostileEntity;
        return true; // All
    }
}
