package ru.bogempty.module.modules.misc;

import org.lwjgl.glfw.GLFW;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;
import ru.bogempty.ui.ClickGui;

public class ClickGuiModule extends Module {
    public ClickGuiModule() {
        super("ClickGUI", Category.MISC);
        this.key = GLFW.GLFW_KEY_RIGHT_SHIFT;
    }

    @Override
    public void onEnable() {
        if (mc != null) {
            mc.setScreen(new ClickGui());
        }
        setEnabled(false); // toggle only opens
    }
}
