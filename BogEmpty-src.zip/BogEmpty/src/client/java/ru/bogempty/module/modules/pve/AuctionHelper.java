package ru.bogempty.module.modules.pve;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;
import ru.bogempty.module.setting.BooleanSetting;

public class AuctionHelper extends Module {
    public final BooleanSetting autoSearch = new BooleanSetting("AutoSearch", true);

    public AuctionHelper() {
        super("AuctionHelper", Category.PVE);
    }

    // bind to search item in hand on auction
}
