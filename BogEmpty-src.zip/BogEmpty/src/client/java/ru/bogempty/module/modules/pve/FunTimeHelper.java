package ru.bogempty.module.modules.pve;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class FunTimeHelper extends Module {
    public FunTimeHelper() {
        super("FunTimeHelper", Category.PVE);
    }

    // bind for buffs / desks / pot usage
}
