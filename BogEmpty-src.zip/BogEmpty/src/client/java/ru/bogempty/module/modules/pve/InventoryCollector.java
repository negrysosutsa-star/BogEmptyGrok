package ru.bogempty.module.modules.pve;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class InventoryCollector extends Module {
    public InventoryCollector() {
        super("InventoryCollector", Category.PVE);
    }

    // auto take items from containers by whitelist — expand later
}
