package ru.bogempty.module.modules.visuals;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;
import ru.bogempty.module.setting.NumberSetting;

public class AspectRatio extends Module {
    public final NumberSetting ratio = new NumberSetting("Ratio", 1.78, 0.5, 3.0, 0.01);

    public AspectRatio() {
        super("AspectRatio", Category.VISUALS);
    }

    // applied via mixin on GameRenderer.getBasicProjectionMatrix
}
