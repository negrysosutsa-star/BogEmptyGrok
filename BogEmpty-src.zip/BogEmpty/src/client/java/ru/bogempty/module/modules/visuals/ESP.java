package ru.bogempty.module.modules.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;
import ru.bogempty.module.setting.BooleanSetting;
import ru.bogempty.module.setting.ModeSetting;

public class ESP extends Module {
    public final ModeSetting targets = new ModeSetting("Targets", "Players", "Players", "Mobs", "All");
    public final BooleanSetting box = new BooleanSetting("Box", true);
    public final BooleanSetting nametag = new BooleanSetting("Nametag", true);

    public ESP() {
        super("ESP", Category.VISUALS);
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        // simple 2d projection placeholder — real box needs world-to-screen
        // full implementation requires matrix access from render3d
    }
}
