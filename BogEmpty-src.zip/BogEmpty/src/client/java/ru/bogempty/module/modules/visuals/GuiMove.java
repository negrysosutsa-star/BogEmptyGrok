package ru.bogempty.module.modules.visuals;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;

public class GuiMove extends Module {
    public GuiMove() {
        super("GuiMove", Category.VISUALS);
    }

    // movement while inventory open via mixin on KeyboardInput / ClientPlayerEntity
}
