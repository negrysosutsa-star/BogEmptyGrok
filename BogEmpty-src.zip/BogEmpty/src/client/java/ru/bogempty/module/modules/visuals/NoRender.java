package ru.bogempty.module.modules.visuals;

import ru.bogempty.module.Category;
import ru.bogempty.module.Module;
import ru.bogempty.module.setting.BooleanSetting;

public class NoRender extends Module {
    public final BooleanSetting fire = new BooleanSetting("Fire", true);
    public final BooleanSetting hurtcam = new BooleanSetting("HurtCam", true);
    public final BooleanSetting scoreboard = new BooleanSetting("Scoreboard", false);
    public final BooleanSetting bossbar = new BooleanSetting("BossBar", false);

    public NoRender() {
        super("NoRender", Category.VISUALS);
    }
}
