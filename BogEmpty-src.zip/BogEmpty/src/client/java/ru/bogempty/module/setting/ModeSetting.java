package ru.bogempty.module.setting;

public class ModeSetting extends Setting {
    private String value;
    public final String[] modes;

    public ModeSetting(String name, String defaultValue, String... modes) {
        super(name);
        this.value = defaultValue;
        this.modes = modes;
    }

    public String get() {
        return value;
    }

    public boolean is(String mode) {
        return value.equalsIgnoreCase(mode);
    }

    public void set(String value) {
        for (String m : modes) {
            if (m.equalsIgnoreCase(value)) {
                this.value = m;
                return;
            }
        }
    }

    public void cycle() {
        int idx = 0;
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equals(value)) {
                idx = i;
                break;
            }
        }
        value = modes[(idx + 1) % modes.length];
    }
}
