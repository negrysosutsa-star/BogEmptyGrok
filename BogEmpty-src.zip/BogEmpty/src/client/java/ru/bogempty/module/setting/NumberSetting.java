package ru.bogempty.module.setting;

public class NumberSetting extends Setting {
    private double value;
    public final double min, max, step;

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name);
        this.value = defaultValue;
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double get() {
        return value;
    }

    public float getFloat() {
        return (float) value;
    }

    public int getInt() {
        return (int) value;
    }

    public void set(double value) {
        this.value = Math.max(min, Math.min(max, value));
    }
}
