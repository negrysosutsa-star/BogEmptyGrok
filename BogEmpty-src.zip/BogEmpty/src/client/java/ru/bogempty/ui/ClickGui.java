package ru.bogempty.ui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import ru.bogempty.module.Category;
import ru.bogempty.module.Module;
import ru.bogempty.module.ModuleManager;

import java.util.List;

public class ClickGui extends Screen {
    private Category selected = Category.COMBAT;

    public ClickGui() {
        super(Text.literal("BogEmpty"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // blur-like dark background
        ctx.fill(0, 0, width, height, 0xAA000000);

        int panelX = 40;
        int panelY = 40;
        int panelW = 140;
        int panelH = 280;

        // categories
        int catY = panelY;
        for (Category cat : Category.values()) {
            boolean sel = cat == selected;
            int col = sel ? 0xFFAA00FF : 0xFF333333;
            ctx.fill(panelX, catY, panelX + panelW, catY + 22, col);
            ctx.drawText(textRenderer, cat.name, panelX + 8, catY + 7, 0xFFFFFFFF, false);
            catY += 24;
        }

        // modules of selected category
        int modX = panelX + panelW + 20;
        int modY = panelY;
        List<Module> mods = ModuleManager.getByCategory(selected);
        for (Module m : mods) {
            int col = m.enabled ? 0xFFAA00FF : 0xFF222222;
            ctx.fill(modX, modY, modX + 160, modY + 20, col);
            ctx.drawText(textRenderer, m.name, modX + 6, modY + 6, 0xFFFFFFFF, false);
            modY += 24;
        }

        // footer
        ctx.drawText(textRenderer, "https://t.me/BogEmptyy", 10, height - 15, 0xFFAA00FF, false);
        ctx.drawText(textRenderer, "BOGEMPTY", width - 80, 8, 0xFFAA00FF, true);

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int panelX = 40;
        int panelY = 40;
        int panelW = 140;

        int catY = panelY;
        for (Category cat : Category.values()) {
            if (mouseX >= panelX && mouseX <= panelX + panelW && mouseY >= catY && mouseY <= catY + 22) {
                selected = cat;
                return true;
            }
            catY += 24;
        }

        int modX = panelX + panelW + 20;
        int modY = panelY;
        List<Module> mods = ModuleManager.getByCategory(selected);
        for (Module m : mods) {
            if (mouseX >= modX && mouseX <= modX + 160 && mouseY >= modY && mouseY <= modY + 20) {
                m.toggle();
                return true;
            }
            modY += 24;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
